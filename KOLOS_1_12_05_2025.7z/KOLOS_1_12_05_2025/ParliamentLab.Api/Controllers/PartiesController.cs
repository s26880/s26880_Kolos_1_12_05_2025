﻿using Microsoft.AspNetCore.Mvc;
using Sejm.Api.Dtos;
using Sejm.Api.Services;

namespace Sejm.Api.Controllers;

[ApiController]
[Route("[controller]")]
public class PartiesController(IPartyService service) : ControllerBase
{
    private readonly IPartyService _service = service;


    [HttpPost("/partie")]
    public async Task<ActionResult<PartyResponse>> Create([FromBody] CreatePartyRequest request, CancellationToken ct)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var response = await _service.CreateAsync(request, ct);
        return CreatedAtAction(nameof(Create), new { id = response.Id }, response);
    }
}