﻿using Microsoft.AspNetCore.Mvc;
using Sejm.Api.Dtos;
using Sejm.Api.Services;

namespace Sejm.Api.Controllers;

[ApiController]
[Route("[controller]")]
public class PoliticiansController(IPoliticianService service) : ControllerBase
{
    private readonly IPoliticianService _service = service;


    [HttpGet("/politycy")]
    public async Task<ActionResult<IEnumerable<PoliticianDto>>> GetAll(CancellationToken ct)
    {
        var list = await _service.GetAllAsync(ct);
        return Ok(list);
    }
}