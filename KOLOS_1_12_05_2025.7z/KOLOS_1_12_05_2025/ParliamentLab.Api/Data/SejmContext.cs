﻿using Microsoft.EntityFrameworkCore;
using ParliamentLab.Api.Models;
using Polityk = Sejm.Api.Models.Polityk;
using Przynaleznosc = Sejm.Api.Models.Przynaleznosc;

namespace Sejm.Api.Data;

public class SejmContext(DbContextOptions<SejmContext> options) : DbContext(options)
{
    public DbSet<Partia> Partie => Set<Partia>();
    public DbSet<Polityk> Politycy => Set<Polityk>();
    public DbSet<Przynaleznosc> Przynaleznosci => Set<Przynaleznosc>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Partia>(e =>
        {
            e.ToTable("Partia");
            e.HasKey(p => p.Id);
            e.Property(p => p.Nazwa).HasMaxLength(300).IsRequired();
            e.Property(p => p.Skrot).HasMaxLength(10);
        });

        builder.Entity<Polityk>(e =>
        {
            e.ToTable("Polityk");
            e.HasKey(p => p.Id);
            e.Property(p => p.Imie).HasMaxLength(50).IsRequired();
            e.Property(p => p.Nazwisko).HasMaxLength(100).IsRequired();
            e.Property(p => p.Powiedzenie).HasMaxLength(200);
        });

        builder.Entity<Przynaleznosc>(e =>
        {
            e.ToTable("Przynaleznosc");
            e.HasKey(p => p.Id);

            e.HasOne(p => p.Partia)
                .WithMany(p => p.Przynaleznosci)
                .HasForeignKey(p => p.PartiaId);

            e.HasOne(p => p.Polityk)
                .WithMany(p => p.Przynaleznosci)
                .HasForeignKey(p => p.PolitykId);
        });
    }
}