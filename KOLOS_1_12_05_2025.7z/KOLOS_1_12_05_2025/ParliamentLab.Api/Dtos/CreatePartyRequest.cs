﻿namespace Sejm.Api.Dtos;

public record CreatePartyRequest(
    string Nazwa,
    string? Skrot,
    DateTime DataZalozenia,
    List<int>? Czlonkowie);