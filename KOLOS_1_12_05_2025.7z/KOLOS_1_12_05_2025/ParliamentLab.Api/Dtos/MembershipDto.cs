﻿namespace Sejm.Api.Dtos;

public record MembershipDto(
    string Nazwa,
    string? Skrot,
    DateTime DataZalozenia,
    DateTime Od,
    DateTime? Do);