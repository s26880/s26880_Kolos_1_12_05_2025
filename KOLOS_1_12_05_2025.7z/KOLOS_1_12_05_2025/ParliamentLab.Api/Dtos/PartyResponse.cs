﻿namespace Sejm.Api.Dtos;

public record PartyResponse(
    int Id,
    string Nazwa,
    string? Skrot,
    DateTime DataZalozenia,
    List<SimplePoliticianDto> Czlonkowie);