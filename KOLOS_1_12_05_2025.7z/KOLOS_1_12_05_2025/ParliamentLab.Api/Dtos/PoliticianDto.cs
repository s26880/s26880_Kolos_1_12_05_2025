﻿namespace Sejm.Api.Dtos;

public record PoliticianDto(
    int Id,
    string Imie,
    string Nazwisko,
    string? Powiedzenie,
    List<MembershipDto> Przynaleznosc);