﻿namespace Sejm.Api.Dtos;

public record SimplePoliticianDto(int Id, string Imie, string Nazwisko, string? Powiedzenie);