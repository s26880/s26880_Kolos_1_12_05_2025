﻿namespace ParliamentLab.Api.Models;

public class Partia
{
    public int Id { get; set; }
    public string Nazwa { get; set; } = null!;
    public string? Skrot { get; set; }
    public DateTime DataZalozenia { get; set; }

    public IEnumerable<Sejm.Api.Models.Przynaleznosc> Przynaleznosci { get; set; } = new List<Sejm.Api.Models.Przynaleznosc>();
}


public class Polityk
{
    public int Id { get; set; }
    public string Imie { get; set; } = null!;
    public string Nazwisko { get; set; } = null!;
    public string? Powiedzenie { get; set; }

    public ICollection<Przynaleznosc> Przynaleznosci { get; set; } = new List<Przynaleznosc>();
}


public class Przynaleznosc
{
    public int Id { get; set; }
    public int PartiaId { get; set; }
    public int PolitykId { get; set; }
    public DateTime Od { get; set; }
    public DateTime? Do { get; set; }

    public Partia Partia { get; set; } = null!;
    public Polityk Polityk { get; set; } = null!;
}
