﻿namespace Sejm.Api.Models;

public class Polityk
{
    public int Id { get; set; }
    public string Imie { get; set; } = null!;
    public string Nazwisko { get; set; } = null!;
    public string? Powiedzenie { get; set; }

    public ICollection<Przynaleznosc> Przynaleznosci { get; set; } = new List<Przynaleznosc>();
}