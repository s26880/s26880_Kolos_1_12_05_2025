﻿using Sejm.Api.Dtos;

namespace Sejm.Api.Services;

public interface IPartyService
{
    Task<PartyResponse> CreateAsync(CreatePartyRequest request, CancellationToken ct = default);
}