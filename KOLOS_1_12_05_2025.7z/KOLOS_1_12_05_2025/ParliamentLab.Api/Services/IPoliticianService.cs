﻿using Sejm.Api.Dtos;

namespace Sejm.Api.Services;

public interface IPoliticianService
{
    Task<IEnumerable<PoliticianDto>> GetAllAsync(CancellationToken ct = default);
}