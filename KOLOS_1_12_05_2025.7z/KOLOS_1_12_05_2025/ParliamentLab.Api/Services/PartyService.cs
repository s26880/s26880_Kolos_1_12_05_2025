﻿using Microsoft.EntityFrameworkCore;
using ParliamentLab.Api.Models;
using Sejm.Api.Data;
using Sejm.Api.Dtos;
using Przynaleznosc = Sejm.Api.Models.Przynaleznosc;

namespace Sejm.Api.Services;

public class PartyService(SejmContext db) : IPartyService
{
    private readonly SejmContext _db = db;

    public async Task<PartyResponse> CreateAsync(CreatePartyRequest request, CancellationToken ct = default)
    {
        var partia = new Partia
        {
            Nazwa = request.Nazwa,
            Skrot = request.Skrot,
            DataZalozenia = request.DataZalozenia
        };

        _db.Partie.Add(partia);
        await _db.SaveChangesAsync(ct);

        if (request.Czlonkowie is { Count: > 0 })
        {
            var politycy = await _db.Politycy
                .Where(p => request.Czlonkowie.Contains(p.Id))
                .ToListAsync(ct);

            foreach (var pol in politycy)
            {
                _db.Przynaleznosci.Add(new Przynaleznosc
                {
                    PartiaId = partia.Id,
                    PolitykId = pol.Id,
                    Od = DateTime.UtcNow
                });
            }
            await _db.SaveChangesAsync(ct);
        }

        var members = await _db.Przynaleznosci
            .Where(m => m.PartiaId == partia.Id)
            .Include(m => m.Polityk)
            .Select(m => m.Polityk)
            .ToListAsync(ct);

        return new PartyResponse(
            partia.Id,
            partia.Nazwa,
            partia.Skrot,
            partia.DataZalozenia,
            members.Select(p => new SimplePoliticianDto(p.Id, p.Imie, p.Nazwisko, p.Powiedzenie)).ToList());
    }
}