﻿using Microsoft.EntityFrameworkCore;
using Sejm.Api.Data;
using Sejm.Api.Dtos;

namespace Sejm.Api.Services;

public class PoliticianService(SejmContext db) : IPoliticianService
{
    private readonly SejmContext _db = db;

    public async Task<IEnumerable<PoliticianDto>> GetAllAsync(CancellationToken ct = default)
    {
        var list = await _db.Politycy
            .Include(p => p.Przynaleznosci)
            .ThenInclude(m => m.Partia)
            .AsNoTracking()
            .ToListAsync(ct);

        return list.Select(p => new PoliticianDto(
            p.Id,
            p.Imie,
            p.Nazwisko,
            p.Powiedzenie,
            p.Przynaleznosci.Select(m => new MembershipDto(
                m.Partia.Nazwa,
                m.Partia.Skrot,
                m.Partia.DataZalozenia,
                m.Od,
                m.Do)).ToList()));
    }
}